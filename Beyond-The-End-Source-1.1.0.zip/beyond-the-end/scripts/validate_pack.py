#!/usr/bin/env python3
"""Offline structural validation for the companion Minecraft resource pack."""
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "resource-pack"
meta = json.loads((ROOT / "pack.mcmeta").read_text(encoding="utf-8"))
assert meta["pack"]["pack_format"] == 75, "Expected Java 1.21.11 resource pack format 75"

items = sorted((ROOT / "assets/beyondtheend/items").glob("*.json"))
assert len(items) == 4, f"Expected 4 item definitions, found {len(items)}"
for item in items:
    definition = json.loads(item.read_text(encoding="utf-8"))
    model_id = definition["model"]["model"]
    namespace, model_path = model_id.split(":", 1)
    model_file = ROOT / "assets" / namespace / "models" / f"{model_path}.json"
    assert model_file.is_file(), f"Missing model: {model_file}"
    model = json.loads(model_file.read_text(encoding="utf-8"))
    texture_id = model["textures"]["layer0"]
    texture_namespace, texture_path = texture_id.split(":", 1)
    texture_file = ROOT / "assets" / texture_namespace / "textures" / f"{texture_path}.png"
    assert texture_file.is_file(), f"Missing texture: {texture_file}"
    data = texture_file.read_bytes()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", f"Invalid PNG: {texture_file}"
    width, height = struct.unpack(">II", data[16:24])
    assert width == 32 and height == 32, f"Expected 32x32 icon: {texture_file} ({width}x{height})"

print(f"Resource pack OK: {len(items)} item definitions, models and 32x32 textures; format 75.")
