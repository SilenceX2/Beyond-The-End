package com.beyondtheend;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.WorldInitEvent;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.LimitedRegion;
import org.bukkit.generator.WorldInfo;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Locale;
import java.util.Random;

public final class BeyondTheEndPlugin extends JavaPlugin implements Listener {
    private NamespacedKey creatureKey;
    private NamespacedKey creatureTypeKey;
    private final Random random = new Random();
    private volatile GenerationSettings generationSettings = new GenerationSettings(true, 420, 7, 0.008, 220);
    private final EndPopulator endPopulator = new EndPopulator();
    private static final String PREFIX = ChatColor.DARK_PURPLE + "[Beyond The End] " + ChatColor.LIGHT_PURPLE;

    @Override public void onEnable() {
        saveDefaultConfig();
        creatureKey = new NamespacedKey(this, "custom_creature");
        creatureTypeKey = new NamespacedKey(this, "creature_type");
        refreshGenerationSettings();
        Bukkit.getPluginManager().registerEvents(this, this);
        for (World world : Bukkit.getWorlds()) registerPopulator(world);
        getLogger().info("Beyond The End 1.1.0 enabled. New outer-End chunks only.");
        startAmbientTask();
    }

    @Override public void onDisable() { getLogger().info("Beyond The End disabled."); }

    @EventHandler public void onWorldInit(WorldInitEvent event) {
        registerPopulator(event.getWorld());
    }

    private void registerPopulator(World world) {
        if (world.getEnvironment() != World.Environment.THE_END) return;
        if (world.getPopulators().stream().noneMatch(populator -> populator instanceof EndPopulator)) {
            world.getPopulators().add(endPopulator);
            getLogger().info("Registered outer-End block populator for world " + world.getName());
        }
    }

    private void refreshGenerationSettings() {
        generationSettings = new GenerationSettings(
                getConfig().getBoolean("world-generation.enabled", true),
                Math.max(0, getConfig().getDouble("world-generation.minimum-distance-from-origin", 420)),
                Math.max(1, Math.min(24, getConfig().getInt("world-generation.decoration-per-chunk", 7))),
                clampChance(getConfig().getDouble("world-generation.rare-structure-chance", 0.008)),
                Math.max(1, Math.min(500, getConfig().getInt("performance.max-decoration-blocks-per-chunk", 220)))
        );
    }

    private double clampChance(double value) { return Math.max(0.0, Math.min(1.0, value)); }

    @EventHandler public void onChunkLoad(ChunkLoadEvent event) {
        // Block placement belongs to EndPopulator. This event is used only for entity spawning.
        if (!event.isNewChunk() || !getConfig().getBoolean("creatures.natural-spawns", true)) return;
        World world = event.getWorld();
        if (world.getEnvironment() != World.Environment.THE_END) return;
        int cx = event.getChunk().getX(), cz = event.getChunk().getZ();
        double centerX = cx * 16.0 + 8, centerZ = cz * 16.0 + 8;
        if (Math.hypot(centerX, centerZ) < generationSettings.minimumDistance()) return;
        Random chunkRandom = new Random(world.getSeed() ^ (((long) cx) << 32) ^ (cz & 0xffffffffL) ^ 0xB7E0D5L);
        if (chunkRandom.nextDouble() < clampChance(getConfig().getDouble("creatures.chance-per-new-chunk", 0.025))) {
            spawnNaturalCreature(world, cx, cz, chunkRandom);
        }
    }

    private final class EndPopulator extends BlockPopulator {
        @Override
        public void populate(WorldInfo worldInfo, Random random, int chunkX, int chunkZ, LimitedRegion region) {
            GenerationSettings settings = generationSettings;
            if (!settings.enabled() || worldInfo.getEnvironment() != World.Environment.THE_END) return;
            double centerX = chunkX * 16.0 + 8, centerZ = chunkZ * 16.0 + 8;
            if (Math.hypot(centerX, centerZ) < settings.minimumDistance()) return;
            decorateChunk(region, chunkX, chunkZ, random, worldInfo.getMinHeight(), worldInfo.getMaxHeight(), settings);
        }
    }

    private void decorateChunk(LimitedRegion region, int cx, int cz, Random r, int minY, int maxY, GenerationSettings settings) {
        BiomeStyle style = styleAt(cx, cz);
        int placed = 0;
        for (int i = 0; i < settings.decorationAttempts(); i++) {
            int x = cx * 16 + 2 + r.nextInt(12), z = cz * 16 + 2 + r.nextInt(12);
            int groundY = region.getHighestBlockYAt(x, z);
            if (groundY < minY || groundY >= maxY - 12) continue;
            Material ground = region.getType(x, groundY, z);
            if (ground != Material.END_STONE && ground != Material.END_STONE_BRICKS) continue;
            int y = groundY + 1;
            if (!isReplaceable(region, x, y, z)) continue;
            switch (style) {
                case ETHEREAL -> placed += placeEthereal(region, x, y, z, r, minY, maxY);
                case AMETHYST -> placed += placeAmethyst(region, x, y, z, r, minY, maxY);
                case CRIMSON -> placed += placeCrimson(region, x, y, z, r, minY, maxY);
                case MUSHROOM -> placed += placeMushroom(region, x, y, z, r, minY, maxY);
                case CELESTIAL -> placed += placeCrystal(region, x, y, z, r, minY, maxY);
            }
            if (placed >= settings.maxDecorationBlocks()) break;
        }
        if (r.nextDouble() < settings.rareStructureChance()) {
            int x = cx * 16 + 8, z = cz * 16 + 8;
            int groundY = region.getHighestBlockYAt(x, z);
            if (groundY > minY && region.getType(x, groundY, z) == Material.END_STONE) {
                buildRuin(region, x, groundY + 1, z, style, r, minY, maxY);
            }
        }
    }

    private boolean isReplaceable(LimitedRegion region, int x, int y, int z) {
        if (!region.isInRegion(x, y, z)) return false;
        Material material = region.getType(x, y, z);
        return material.isAir() || !material.isSolid();
    }

    private int placeEthereal(LimitedRegion region, int x, int y, int z, Random r, int minY, int maxY) {
        Material[] plants = {Material.LIGHT_BLUE_CANDLE, Material.CYAN_CANDLE, Material.SEA_LANTERN};
        int placed = 0;
        if (isReplaceable(region, x, y, z)) { region.setType(x, y, z, plants[r.nextInt(plants.length)]); placed++; }
        if (r.nextDouble() < .34) placed += smallTree(region, x, y + 1, z, Material.WARPED_STEM, Material.WARPED_WART_BLOCK, r, 4, 6, minY, maxY);
        return placed;
    }

    private int placeAmethyst(LimitedRegion region, int x, int y, int z, Random r, int minY, int maxY) {
        if (r.nextDouble() < .45) return smallTree(region, x, y, z, Material.CRIMSON_STEM, Material.PURPLE_WOOL, r, 3, 5, minY, maxY);
        if (isReplaceable(region, x, y, z)) { region.setType(x, y, z, r.nextBoolean() ? Material.PURPLE_CANDLE : Material.MAGENTA_CANDLE); return 1; }
        return 0;
    }

    private int placeCrimson(LimitedRegion region, int x, int y, int z, Random r, int minY, int maxY) {
        if (r.nextDouble() < .5) return smallTree(region, x, y, z, Material.CRIMSON_STEM, Material.NETHER_WART_BLOCK, r, 3, 5, minY, maxY);
        if (isReplaceable(region, x, y, z)) { region.setType(x, y, z, Material.RED_MUSHROOM); return 1; }
        return 0;
    }

    private int placeMushroom(LimitedRegion region, int x, int y, int z, Random r, int minY, int maxY) {
        int h = 3 + r.nextInt(4);
        if (!canPlaceColumn(region, x, y, z, h + 1, minY, maxY)) return 0;
        int placed = 0;
        for (int dy = 0; dy < h; dy++) if (placeIfAir(region, x, y + dy, z, Material.MUSHROOM_STEM)) placed++;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            if (Math.abs(dx) + Math.abs(dz) <= 3) {
                Material cap = r.nextBoolean() ? Material.PURPLE_WOOL : Material.MAGENTA_WOOL;
                if (placeIfAir(region, x + dx, y + h, z + dz, cap)) placed++;
            }
        }
        return placed;
    }

    private int placeCrystal(LimitedRegion region, int x, int y, int z, Random r, int minY, int maxY) {
        int h = 2 + r.nextInt(4);
        if (!canPlaceColumn(region, x, y, z, h, minY, maxY)) return 0;
        int placed = 0;
        for (int dy = 0; dy < h; dy++) if (placeIfAir(region, x, y + dy, z, Material.AMETHYST_BLOCK)) placed++;
        if (r.nextBoolean() && placeIfAir(region, x + 1, y, z, Material.AMETHYST_BLOCK)) placed++;
        return placed;
    }

    private boolean canPlaceColumn(LimitedRegion region, int x, int y, int z, int height, int minY, int maxY) {
        if (y < minY || y + height >= maxY) return false;
        for (int dy = 0; dy < height; dy++) if (!isReplaceable(region, x, y + dy, z)) return false;
        return true;
    }

    private boolean placeIfAir(LimitedRegion region, int x, int y, int z, Material material) {
        if (!isReplaceable(region, x, y, z)) return false;
        region.setType(x, y, z, material);
        return true;
    }

    private int smallTree(LimitedRegion region, int x, int y, int z, Material trunk, Material crown, Random r, int min, int max, int minY, int maxY) {
        if (Math.floorMod(x, 16) < 2 || Math.floorMod(x, 16) > 13 || Math.floorMod(z, 16) < 2 || Math.floorMod(z, 16) > 13) return 0;
        int h = min + r.nextInt(max - min + 1);
        if (!canPlaceColumn(region, x, y, z, h + 2, minY, maxY)) return 0;
        int top = y + h - 1, placed = 0;
        for (int dy = 0; dy < h; dy++) if (placeIfAir(region, x, y + dy, z, trunk)) placed++;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int dy = -1; dy <= 1; dy++) {
            if (Math.abs(dx) + Math.abs(dz) + Math.abs(dy) < 5 && placeIfAir(region, x + dx, top + dy, z + dz, crown)) placed++;
        }
        return placed;
    }

    private void buildRuin(LimitedRegion region, int x, int y, int z, BiomeStyle style, Random r, int minY, int maxY) {
        if (y < minY || y + 5 >= maxY) return;
        Material block = style == BiomeStyle.CELESTIAL ? Material.PURPUR_BLOCK : Material.END_STONE_BRICKS;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            if (Math.abs(dx) == 2 || Math.abs(dz) == 2) placeIfAir(region, x + dx, y, z + dz, block);
        }
        for (int dy = 1; dy <= 3; dy++) {
            placeIfAir(region, x - 2, y + dy, z - 2, block); placeIfAir(region, x + 2, y + dy, z - 2, block);
            placeIfAir(region, x - 2, y + dy, z + 2, block); placeIfAir(region, x + 2, y + dy, z + 2, block);
        }
        if (placeIfAir(region, x, y + 1, z, Material.CHEST)) {
            var state = region.getBlockState(x, y + 1, z);
            if (state instanceof org.bukkit.block.Chest chest) {
                chest.getBlockInventory().addItem(new ItemStack(Material.AMETHYST_SHARD, 2 + r.nextInt(3)));
                chest.getBlockInventory().addItem(new ItemStack(Material.ENDER_PEARL, 1 + r.nextInt(2)));
                region.setBlockState(x, y + 1, z, chest);
            }
        }
    }

    private void spawnNaturalCreature(World w, int cx, int cz, Random rng) {
        int maxPerChunk = Math.max(0, getConfig().getInt("creatures.max-custom-creatures-per-chunk", 2));
        if (maxPerChunk == 0) return;
        long existing = java.util.Arrays.stream(w.getChunkAt(cx, cz).getEntities())
                .filter(e -> e.getPersistentDataContainer().has(creatureKey, PersistentDataType.BYTE)).count();
        if (existing >= maxPerChunk) return;
        int x = cx * 16 + 2 + rng.nextInt(12), z = cz * 16 + 2 + rng.nextInt(12), y = w.getHighestBlockYAt(x, z);
        if (y <= w.getMinHeight() || y >= w.getMaxHeight() - 2) return;
        Material floor = w.getBlockAt(x, y, z).getType();
        if (floor != Material.END_STONE && floor != Material.END_STONE_BRICKS) return;
        if (!w.getBlockAt(x, y + 1, z).isPassable() || !w.getBlockAt(x, y + 2, z).isPassable()) return;
        y += 1;
        BiomeStyle region = styleAt(cx, cz);
        String[] types = switch (region) {
            case ETHEREAL -> new String[]{"moth", "moth", "wisp"};
            case AMETHYST -> new String[]{"moth", "wisp", "wisp"};
            case CRIMSON -> new String[]{"stalker", "stalker", "wisp"};
            case MUSHROOM -> new String[]{"moth", "wisp"};
            case CELESTIAL -> new String[]{"wisp", "guardian", "wisp", "guardian"};
        };
        for (int tries = 0; tries < types.length; tries++) {
            String t = types[rng.nextInt(types.length)];
            if (getConfig().getBoolean("creatures." + creatureConfig(t), true)) {
                spawnCreature(w, new Location(w, x + .5, y, z + .5), t);
                break;
            }
        }
    }
    private String creatureConfig(String t) { return switch (t) { case "moth" -> "celestial-moth"; case "wisp" -> "void-wisp"; case "stalker" -> "end-stalker"; default -> "crystal-guardian"; }; }

    private void spawnCreature(World w, Location loc, String type) {
        EntityType entityType = switch (type) { case "moth" -> EntityType.ALLAY; case "wisp" -> EntityType.PHANTOM; case "stalker" -> EntityType.ENDERMAN; default -> EntityType.IRON_GOLEM; };
        Entity raw = w.spawnEntity(loc, entityType);
        if (!(raw instanceof LivingEntity mob)) { raw.remove(); return; }
        String name = switch (type) { case "moth" -> "§bCelestial Moth"; case "wisp" -> "§dVoid Wisp"; case "stalker" -> "§5End Stalker"; default -> "§3Crystal Guardian"; };
        mob.setCustomName(name); mob.setCustomNameVisible(true);
        mob.getPersistentDataContainer().set(creatureKey, PersistentDataType.BYTE, (byte) 1);
        mob.getPersistentDataContainer().set(creatureTypeKey, PersistentDataType.STRING, type);
        double health = switch (type) { case "moth" -> 8; case "wisp" -> 18; case "stalker" -> 40; default -> 110; };
        setAttribute(mob, Attribute.MAX_HEALTH, health); mob.setHealth(health);
        if (type.equals("wisp")) { setAttribute(mob, Attribute.MOVEMENT_SPEED, .32); }
        if (type.equals("stalker")) { setAttribute(mob, Attribute.ATTACK_DAMAGE, 9); setAttribute(mob, Attribute.MOVEMENT_SPEED, .34); }
        if (type.equals("guardian")) { setAttribute(mob, Attribute.ATTACK_DAMAGE, 14); setAttribute(mob, Attribute.MOVEMENT_SPEED, .28); }
        if (type.equals("moth") || type.equals("wisp")) mob.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, false, false));
        if (type.equals("guardian")) mob.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        if ((type.equals("stalker") || type.equals("guardian")) && mob instanceof Mob aiMob) {
            new BukkitRunnable() {
                @Override public void run() {
                    if (!aiMob.isValid() || aiMob.isDead()) { cancel(); return; }
                    var target = aiMob.getWorld().getNearbyPlayers(aiMob.getLocation(), 18).stream().findFirst().orElse(null);
                    if (target != null) aiMob.setTarget(target);
                }
            }.runTaskTimer(this, 20L, 40L);
        }
    }
    private void setAttribute(LivingEntity e, Attribute a, double value) { if (e.getAttribute(a) != null) e.getAttribute(a).setBaseValue(value); }

    @EventHandler public void onCustomCreatureDeath(EntityDeathEvent event) {
        Entity e = event.getEntity();
        String type = e.getPersistentDataContainer().get(creatureTypeKey, PersistentDataType.STRING);
        if (type == null) return;
        event.getDrops().clear();
        switch (type) {
            case "wisp" -> event.getDrops().add(namedItem(Material.AMETHYST_SHARD, "§dVoid Shard", "§7A fragment humming with End energy.", "void_shard"));
            case "stalker" -> event.getDrops().add(namedItem(Material.ECHO_SHARD, "§5Stalker Core", "§7A cold fragment from the outer void.", "stalker_core"));
            case "guardian" -> { event.getDrops().add(namedItem(Material.PRISMARINE_CRYSTALS, "§3Guardian Crystal", "§7A powerful crystalline trophy.", "guardian_crystal")); event.getDrops().add(new ItemStack(Material.AMETHYST_SHARD, 2 + random.nextInt(3))); }
            case "moth" -> event.getDrops().add(namedItem(Material.GLOW_INK_SAC, "§bMoth Dust", "§7Softly glowing dust.", "moth_dust"));
        }
    }
    private ItemStack namedItem(Material material, String name, String lore, String modelId) {
        ItemStack item = new ItemStack(material);
        var meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(java.util.List.of(lore));
            meta.setItemModel(new NamespacedKey(this, modelId));
            item.setItemMeta(meta);
        }
        return item;
    }

    private record GenerationSettings(boolean enabled, double minimumDistance, int decorationAttempts,
                                      double rareStructureChance, int maxDecorationBlocks) { }

    private enum BiomeStyle { ETHEREAL, AMETHYST, CRIMSON, MUSHROOM, CELESTIAL }
    private BiomeStyle styleAt(int cx, int cz) {
        long h = mix(((long) (cx >> 3) * 341873128712L) ^ ((long) (cz >> 3) * 132897987541L));
        return BiomeStyle.values()[(int) Math.floorMod(h, 5)];
    }
    private long mix(long z) { z = (z ^ (z >>> 30)) * 0xbf58476d1ce4e5b9L; z = (z ^ (z >>> 27)) * 0x94d049bb133111ebL; return z ^ (z >>> 31); }

    private void startAmbientTask() {
        new BukkitRunnable() { @Override public void run() {
            if (!getConfig().getBoolean("effects.ambient-particles", true)) return;
            for (var player : Bukkit.getOnlinePlayers()) {
                if (player.getWorld().getEnvironment() != World.Environment.THE_END || random.nextDouble() > clampChance(getConfig().getDouble("effects.particle-chance-per-second", .18))) continue;
                Location l = player.getLocation().add(random.nextDouble() * 12 - 6, random.nextDouble() * 5, random.nextDouble() * 12 - 6);
                Particle ambient = switch (styleAt(player.getLocation().getChunk().getX(), player.getLocation().getChunk().getZ())) {
                    case ETHEREAL -> Particle.END_ROD;
                    case AMETHYST -> Particle.WITCH;
                    case CRIMSON -> Particle.ASH;
                    case MUSHROOM -> Particle.SPORE_BLOSSOM_AIR;
                    case CELESTIAL -> Particle.PORTAL;
                };
                player.spawnParticle(ambient, l, 2, .15, .25, .15, .01);
            }
        }}.runTaskTimer(this, 20L, 20L);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("beyondtheend.admin")) { sender.sendMessage(ChatColor.RED + "You do not have permission."); return true; }
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            sender.sendMessage(PREFIX + "Version 1.1.0 | Paper 1.21.11 | Java 21");
            sender.sendMessage(ChatColor.GRAY + "Mixed outer-End decoration; only newly generated chunks are modified."); return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> { reloadConfig(); refreshGenerationSettings(); sender.sendMessage(PREFIX + "Configuration reloaded."); }
            case "debug" -> sender.sendMessage(PREFIX + "Generation=" + getConfig().getBoolean("world-generation.enabled") + ", naturalSpawns=" + getConfig().getBoolean("creatures.natural-spawns"));
            case "locate" -> {
                if (args.length < 2) { sender.sendMessage(ChatColor.RED + "Usage: /beyondend locate <ethereal|amethyst|crimson|mushroom|celestial>"); return true; }
                if (!(sender instanceof org.bukkit.entity.Player p)) { sender.sendMessage("Players only."); return true; }
                String target = args[1].toUpperCase(Locale.ROOT);
                BiomeStyle wanted; try { wanted = BiomeStyle.valueOf(target); } catch (IllegalArgumentException ex) { sender.sendMessage(ChatColor.RED + "Unknown region."); return true; }
                int startX = p.getLocation().getChunk().getX(), startZ = p.getLocation().getChunk().getZ(); boolean found = false;
                for (int radius = 0; radius <= 128 && !found; radius++) for (int dx = -radius; dx <= radius && !found; dx++) for (int dz = -radius; dz <= radius && !found; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                    int cx = startX + dx, cz = startZ + dz;
                    if (Math.hypot(cx * 16.0, cz * 16.0) >= getConfig().getDouble("world-generation.minimum-distance-from-origin", 420) && styleAt(cx, cz) == wanted) {
                        sender.sendMessage(PREFIX + "Nearest " + wanted.name() + " region estimate: X " + (cx * 16 + 8) + ", Z " + (cz * 16 + 8)); found = true;
                    }
                }
                if (!found) sender.sendMessage(ChatColor.RED + "No region found in search radius.");
            }
            case "spawn" -> {
                if (!(sender instanceof org.bukkit.entity.Player p)) { sender.sendMessage("Players only."); return true; }
                if (args.length < 2) { sender.sendMessage(ChatColor.RED + "Usage: /beyondend spawn <moth|wisp|stalker|guardian>"); return true; }
                if (p.getWorld().getEnvironment() != World.Environment.THE_END) { sender.sendMessage(ChatColor.RED + "You must be in the End."); return true; }
                String type = args[1].toLowerCase(Locale.ROOT);
                if (!java.util.List.of("moth", "wisp", "stalker", "guardian").contains(type)) { sender.sendMessage(ChatColor.RED + "Unknown creature."); return true; }
                Location spawnAt = p.getLocation();
                if (spawnAt.getBlock().isLiquid() || !spawnAt.getBlock().isPassable()) {
                    sender.sendMessage(ChatColor.RED + "Move to a clear space before spawning a creature."); return true;
                }
                spawnCreature(p.getWorld(), spawnAt, type); sender.sendMessage(PREFIX + "Spawned " + type + ".");
            }
            default -> sender.sendMessage(ChatColor.YELLOW + "Usage: /beyondend <info|reload|locate|spawn|debug>");
        }
        return true;
    }
}
