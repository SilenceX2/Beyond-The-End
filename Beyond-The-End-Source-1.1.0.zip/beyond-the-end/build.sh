#!/usr/bin/env bash
set -euo pipefail
python3 scripts/validate_pack.py
mvn --batch-mode clean package
printf '\nBuilt: target/beyond-the-end-1.1.0.jar\n'
