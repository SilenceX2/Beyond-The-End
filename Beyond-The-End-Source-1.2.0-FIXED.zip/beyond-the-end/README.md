# Beyond The End — release candidate 1.2.0

**Target:** Minecraft Java 1.21.11 · Paper API 1.21.11 · Java 21  
**Build:** Maven 3.9+  
**Project:** mixed vanilla/custom End expansion

Beyond The End preserves the vanilla End progression (central island, dragon, obsidian pillars, exit portal and gateways). Its additions are deliberately limited to newly generated outer-End chunks beyond a configurable radius.

## What's included

- Five deterministic procedural region styles: **Ethereal Gardens**, **Amethyst Forest**, **Crimson Expanse**, **Void Mushroom Islands** and **Celestial Highlands**.
- Small alien trees, crystal growths, giant mushroom-like formations and rare compact ruins with modest loot.
- Four custom-named creature variants with adjusted health, damage, movement, effects and drops: **Celestial Moth**, **Void Wisp**, **End Stalker** and **Crystal Guardian**.
- Four original pixel-art loot icons, item model definitions and item models in the companion resource pack.
- Region-specific ambient particles, configurable generation and admin commands.
- GitHub Actions workflow to compile the plugin with Java 21 and Maven.

## Honest technical scope

- The five environments are **procedural visual zones**, not registered Minecraft biomes. They do not have independent biome IDs, biome maps, weather or biome-specific mob spawn tables.
- The four creatures use vanilla entity bodies (Allay, Phantom, Enderman and Iron Golem). Their gameplay values and loot are customized; custom 3D entity models/animations are not part of this release.
- Decorations are generated through Paper’s `BlockPopulator` during new chunk generation, using `LimitedRegion` rather than accessing the live world. Creature spawning is handled separately after a new chunk loads. Only passable blocks are replaced, placements are constrained to the chunk, and existing chunks are not retroactively changed.
- As with any world-generation plugin, back up the world and test on a copy first. This build has not been load-tested on a live multiplayer server in this authoring environment.

## Build the plugin

Requirements: **JDK 21** and **Maven 3.9+**, with internet access for the Paper API dependency.

From this folder:

```bash
mvn --batch-mode clean package
```

On Windows, `build.bat` runs the same command; on Linux/macOS, use `./build.sh`.

Expected output:

```text
target/beyond-the-end-1.2.0.jar
```

The source and the API methods used for chunk population, attributes, particles and item models were checked against the Paper 1.21.11 Javadocs, but it could not be compiled here because Maven is unavailable and external package downloads are blocked. Do not treat this ZIP as a prebuilt JAR. The included GitHub Actions workflow will build it in a Maven-enabled runner when pushed to GitHub.

## Install on a test server

1. Stop the test server and make a backup of the world.
2. Build the JAR with the command above (or download the artifact from a successful GitHub Actions run).
3. Put `target/beyond-the-end-1.2.0.jar` in the server's `plugins/` folder.
4. Install the companion resource pack on the server/client. The pack ZIP must contain `pack.mcmeta` at its root; do not zip the containing folder itself.
5. Start Paper 1.21.11 with Java 21 and check the console.
6. Visit unexplored outer-End territory beyond the default 420-block radius. Previously generated chunks will remain unchanged.
7. Use the admin commands below to inspect and test.

## Commands

All commands require `beyondtheend.admin` (default: operators).

- `/beyondend info` — plugin and generation summary.
- `/beyondend debug` — current generation/spawn toggles.
- `/beyondend reload` — reload `config.yml`.
- `/beyondend locate <ethereal|amethyst|crimson|mushroom|celestial>` — estimate the nearest chunk region.
- `/beyondend spawn <moth|wisp|stalker|guardian>` — spawn a test creature (must be in the End).

Alias: `/bte`.

## Configuration

Edit `plugins/BeyondTheEnd/config.yml` and run `/beyondend reload`.

- `world-generation.enabled`: enable/disable new chunk decoration.
- `world-generation.minimum-distance-from-origin`: keep the central island/dragon area vanilla (default 420 blocks).
- `world-generation.decoration-per-chunk`: number of decoration attempts per new chunk (clamped to 1–24).
- `world-generation.rare-structure-chance`: chance of a small ruin per new chunk.
- `creatures.natural-spawns`: enable creature spawns in new chunks.
- `creatures.chance-per-new-chunk`: chance of a creature spawn attempt.
- `creatures.max-custom-creatures-per-chunk`: cap custom creatures in a chunk.
- `effects.ambient-particles`: toggle ambient particles.

## Project layout

- `src/` — Java plugin and Bukkit/Paper configuration.
- `resource-pack/` — complete resource pack (also delivered as a separate ZIP).
- `.github/workflows/build.yml` — CI build with Java 21.
