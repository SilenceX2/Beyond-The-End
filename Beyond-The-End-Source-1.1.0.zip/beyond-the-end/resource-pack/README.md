# Beyond The End Resource Pack — Minecraft Java 1.21.11

This pack supplies four original pixel-art item visuals used by Beyond The End 1.1.0:

- Void Shard
- Stalker Core
- Guardian Crystal
- Moth Dust

Install the ZIP through Minecraft's Resource Packs menu or configure it as your server resource pack. The ZIP must have `pack.mcmeta` at its root. The pack changes loot-item visuals only; creature bodies remain vanilla models.
