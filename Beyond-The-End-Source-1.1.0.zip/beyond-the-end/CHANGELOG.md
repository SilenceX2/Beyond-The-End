# Changelog

## 1.1.0 — final source package

- Bundled the complete resource pack inside the source archive (item definitions, models and textures).
- Updated project metadata and build artifact naming to 1.1.0.
- Moved block generation into Paper’s `BlockPopulator` using `LimitedRegion`, as recommended by the Paper API; kept entity spawning in the chunk-load event.
- Used immutable generation settings in the populator for thread-safe reads and deterministic per-chunk random generation.
- Tightened natural creature spawn checks to require End Stone/End Stone Bricks and two clear blocks above the surface.
- Added region-specific ambient particles.
- Improved manual creature-spawn safety checks and refreshed setup/testing documentation.

## 1.0.1

- Initial mixed outer-End procedural zone implementation and four loot item models.
