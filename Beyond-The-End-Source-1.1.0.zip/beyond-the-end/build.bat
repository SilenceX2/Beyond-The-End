@echo off
setlocal
python scripts\validate_pack.py
if errorlevel 1 exit /b %errorlevel%
call mvn --batch-mode clean package
if errorlevel 1 exit /b %errorlevel%
echo.
echo Built: target\beyond-the-end-1.1.0.jar
