package com.beyondtheend;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Locale;
import java.util.Random;

public final class BeyondTheEndPlugin extends JavaPlugin implements Listener {
    private NamespacedKey creatureKey;
    private NamespacedKey creatureTypeKey;
    private final Random random = new Random();
    private volatile GenerationSettings generationSettings = new GenerationSettings(true, 420, 7, 0.008, 220);
    private static final String PREFIX = ChatColor.DARK_PURPLE + "[Beyond The End] " + ChatColor.LIGHT_PURPLE;

    @Override public void onEnable() {
        saveDefaultConfig();
        creatureKey = new NamespacedKey(this, "custom_creature");
        creatureTypeKey = new NamespacedKey(this, "creature_type");
        refreshGenerationSettings();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("Beyond The End 1.2.0 enabled. Themed outer-End regions apply to newly generated chunks only.");
        startAmbientTask();
    }

    @Override public void onDisable() { getLogger().info("Beyond The End disabled."); }

    private void refreshGenerationSettings() {
        generationSettings = new GenerationSettings(
                getConfig().getBoolean("world-generation.enabled", true),
                Math.max(0, getConfig().getDouble("world-generation.minimum-distance-from-origin", 420)),
                Math.max(1, Math.min(24, getConfig().getInt("world-generation.decoration-per-chunk", 7))),
                clampChance(getConfig().getDouble("world-generation.rare-structure-chance", 0.008)),
                Math.max(1, Math.min(500, getConfig().getInt("performance.max-decoration-blocks-per-chunk", 220)))
        );
    }

    private double clampChance(double value) { return Math.max(0.0, Math.min(1.0, value)); }

    @EventHandler public void onChunkLoad(ChunkLoadEvent event) {
        if (!event.isNewChunk()) return;
        World world = event.getWorld();
        if (world.getEnvironment() != World.Environment.THE_END) return;
        int cx = event.getChunk().getX(), cz = event.getChunk().getZ();
        double centerX = cx * 16.0 + 8, centerZ = cz * 16.0 + 8;
        if (Math.hypot(centerX, centerZ) < generationSettings.minimumDistance()) return;
        // Run one tick later, after Paper has finished placing the new chunk's vanilla terrain.
        Bukkit.getScheduler().runTask(this, () -> {
            if (!world.isChunkLoaded(cx, cz)) return;
            Random chunkRandom = new Random(world.getSeed() ^ (((long) cx) << 32) ^ (cz & 0xffffffffL) ^ 0xB7E0D5L);
            if (generationSettings.enabled()) decorateLoadedChunk(world, cx, cz, chunkRandom);
            if (getConfig().getBoolean("creatures.natural-spawns", true)
                    && chunkRandom.nextDouble() < clampChance(getConfig().getDouble("creatures.chance-per-new-chunk", 0.025))) {
                spawnNaturalCreature(world, cx, cz, chunkRandom);
            }
        });
    }

    // A reliable post-generation pass: unlike a BlockPopulator registration made after
    // a world already exists, this runs when Paper reports a genuinely new chunk.
    private void decorateLoadedChunk(World world, int cx, int cz, Random r) {
        BiomeStyle style = styleAt(cx, cz);
        int attempts = Math.max(8, generationSettings.decorationAttempts() * 2);
        int placed = 0;
        for (int i = 0; i < attempts && placed < generationSettings.maxDecorationBlocks(); i++) {
            int x = cx * 16 + 3 + r.nextInt(10);
            int z = cz * 16 + 3 + r.nextInt(10);
            int y = world.getHighestBlockYAt(x, z);
            if (y <= world.getMinHeight() || y >= world.getMaxHeight() - 12) continue;
            Material floor = world.getBlockAt(x, y, z).getType();
            if (floor != Material.END_STONE && floor != Material.END_STONE_BRICKS) continue;
            int base = y + 1;
            switch (style) {
                case ETHEREAL -> placed += growCrystalBloom(world, x, base, z, r,
                        new Material[]{Material.SEA_LANTERN, Material.LIGHT_BLUE_CANDLE, Material.CYAN_CANDLE}, Material.WARPED_STEM, Material.WARPED_WART_BLOCK);
                case AMETHYST -> placed += growAmethystSpire(world, x, base, z, r);
                case CRIMSON -> placed += growCrimsonGrowth(world, x, base, z, r);
                case MUSHROOM -> placed += growVoidMushroom(world, x, base, z, r);
                case CELESTIAL -> placed += growCelestialPillar(world, x, base, z, r);
            }
        }
        // Recolor several small surface clearings so the five regions are recognizable at a glance.
        Material surface = switch (style) {
            case ETHEREAL -> Material.LIGHT_BLUE_TERRACOTTA;
            case AMETHYST -> Material.PURPLE_TERRACOTTA;
            case CRIMSON -> Material.RED_TERRACOTTA;
            case MUSHROOM -> Material.MAGENTA_TERRACOTTA;
            case CELESTIAL -> Material.PURPUR_BLOCK;
        };
        for (int patch = 0; patch < 2; patch++) {
            int px = cx * 16 + 5 + r.nextInt(6), pz = cz * 16 + 5 + r.nextInt(6);
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                int sx = px + dx, sz = pz + dz, sy = world.getHighestBlockYAt(sx, sz);
                if (sy > world.getMinHeight() && world.getBlockAt(sx, sy, sz).getType() == Material.END_STONE)
                    world.getBlockAt(sx, sy, sz).setType(surface, false);
            }
        }
        // Give every new outer chunk a visible themed ground accent, even with unlucky random rolls.
        int x = cx * 16 + 8, z = cz * 16 + 8, y = world.getHighestBlockYAt(x, z);
        if (y > world.getMinHeight() && y < world.getMaxHeight() - 4
                && world.getBlockAt(x, y, z).getType() == Material.END_STONE) {
            Material accent = switch (style) {
                case ETHEREAL -> Material.SEA_LANTERN;
                case AMETHYST -> Material.AMETHYST_BLOCK;
                case CRIMSON -> Material.RED_MUSHROOM_BLOCK;
                case MUSHROOM -> Material.MUSHROOM_STEM;
                case CELESTIAL -> Material.PURPUR_PILLAR;
            };
            world.getBlockAt(x, y + 1, z).setType(accent, false);
        }
    }

    private int growCrystalBloom(World w, int x, int y, int z, Random r, Material[] accents, Material stem, Material crown) {
        int n = 0; int h = 2 + r.nextInt(3);
        for (int dy = 0; dy < h; dy++) if (w.getBlockAt(x, y + dy, z).isPassable()) { w.getBlockAt(x, y + dy, z).setType(dy == h - 1 ? accents[r.nextInt(accents.length)] : stem, false); n++; }
        if (r.nextBoolean()) for (int dx=-1; dx<=1; dx++) for (int dz=-1; dz<=1; dz++) if (Math.abs(dx)+Math.abs(dz)==1 && w.getBlockAt(x+dx,y+h-1,z+dz).isPassable()) { w.getBlockAt(x+dx,y+h-1,z+dz).setType(crown,false); n++; }
        return n;
    }
    private int growAmethystSpire(World w, int x, int y, int z, Random r) {
        int h=2+r.nextInt(4), n=0; for(int dy=0;dy<h;dy++) if(w.getBlockAt(x,y+dy,z).isPassable()){w.getBlockAt(x,y+dy,z).setType(dy==h-1?Material.BUDDING_AMETHYST:Material.AMETHYST_BLOCK,false);n++;}
        if(w.getBlockAt(x+1,y,z).isPassable()){w.getBlockAt(x+1,y,z).setType(Material.AMETHYST_CLUSTER,false);n++;} return n;
    }
    private int growCrimsonGrowth(World w, int x, int y, int z, Random r) {
        int h=2+r.nextInt(3),n=0; for(int dy=0;dy<h;dy++) if(w.getBlockAt(x,y+dy,z).isPassable()){w.getBlockAt(x,y+dy,z).setType(dy==h-1?Material.NETHER_WART_BLOCK:Material.CRIMSON_STEM,false);n++;}
        if(w.getBlockAt(x+1,y,z).isPassable()){w.getBlockAt(x+1,y,z).setType(Material.RED_MUSHROOM,false);n++;} return n;
    }
    private int growVoidMushroom(World w, int x, int y, int z, Random r) {
        int h=3+r.nextInt(3),n=0; for(int dy=0;dy<h;dy++) if(w.getBlockAt(x,y+dy,z).isPassable()){w.getBlockAt(x,y+dy,z).setType(Material.MUSHROOM_STEM,false);n++;}
        for(int dx=-2;dx<=2;dx++) for(int dz=-2;dz<=2;dz++) if(Math.abs(dx)+Math.abs(dz)<=3 && w.getBlockAt(x+dx,y+h,z+dz).isPassable()){w.getBlockAt(x+dx,y+h,z+dz).setType(r.nextBoolean()?Material.PURPLE_WOOL:Material.MAGENTA_WOOL,false);n++;} return n;
    }
    private int growCelestialPillar(World w, int x, int y, int z, Random r) {
        int h=3+r.nextInt(4),n=0; for(int dy=0;dy<h;dy++) if(w.getBlockAt(x,y+dy,z).isPassable()){w.getBlockAt(x,y+dy,z).setType(dy==h-1?Material.END_ROD:Material.PURPUR_PILLAR,false);n++;} return n;
    }

    private void spawnNaturalCreature(World w, int cx, int cz, Random rng) {
        int maxPerChunk = Math.max(0, getConfig().getInt("creatures.max-custom-creatures-per-chunk", 2));
        if (maxPerChunk == 0) return;
        long existing = java.util.Arrays.stream(w.getChunkAt(cx, cz).getEntities())
                .filter(e -> e.getPersistentDataContainer().has(creatureKey, PersistentDataType.BYTE)).count();
        if (existing >= maxPerChunk) return;
        int x = cx * 16 + 2 + rng.nextInt(12), z = cz * 16 + 2 + rng.nextInt(12), y = w.getHighestBlockYAt(x, z);
        if (y <= w.getMinHeight() || y >= w.getMaxHeight() - 2) return;
        Material floor = w.getBlockAt(x, y, z).getType();
        if (floor != Material.END_STONE && floor != Material.END_STONE_BRICKS) return;
        if (!w.getBlockAt(x, y + 1, z).isPassable() || !w.getBlockAt(x, y + 2, z).isPassable()) return;
        y += 1;
        BiomeStyle region = styleAt(cx, cz);
        String[] types = switch (region) {
            case ETHEREAL -> new String[]{"moth", "moth", "wisp"};
            case AMETHYST -> new String[]{"moth", "wisp", "wisp"};
            case CRIMSON -> new String[]{"stalker", "stalker", "wisp"};
            case MUSHROOM -> new String[]{"moth", "wisp"};
            case CELESTIAL -> new String[]{"wisp", "guardian", "wisp", "guardian"};
        };
        for (int tries = 0; tries < types.length; tries++) {
            String t = types[rng.nextInt(types.length)];
            if (getConfig().getBoolean("creatures." + creatureConfig(t), true)) {
                spawnCreature(w, new Location(w, x + .5, y, z + .5), t);
                break;
            }
        }
    }
    private String creatureConfig(String t) { return switch (t) { case "moth" -> "celestial-moth"; case "wisp" -> "void-wisp"; case "stalker" -> "end-stalker"; default -> "crystal-guardian"; }; }

    private void spawnCreature(World w, Location loc, String type) {
        EntityType entityType = switch (type) { case "moth" -> EntityType.ALLAY; case "wisp" -> EntityType.PHANTOM; case "stalker" -> EntityType.ENDERMAN; default -> EntityType.IRON_GOLEM; };
        Entity raw = w.spawnEntity(loc, entityType);
        if (!(raw instanceof LivingEntity mob)) { raw.remove(); return; }
        String name = switch (type) { case "moth" -> "§bCelestial Moth"; case "wisp" -> "§dVoid Wisp"; case "stalker" -> "§5End Stalker"; default -> "§3Crystal Guardian"; };
        mob.setCustomName(name); mob.setCustomNameVisible(true);
        mob.getPersistentDataContainer().set(creatureKey, PersistentDataType.BYTE, (byte) 1);
        mob.getPersistentDataContainer().set(creatureTypeKey, PersistentDataType.STRING, type);
        double health = switch (type) { case "moth" -> 8; case "wisp" -> 18; case "stalker" -> 40; default -> 110; };
        setAttribute(mob, Attribute.MAX_HEALTH, health); mob.setHealth(health);
        if (type.equals("wisp")) { setAttribute(mob, Attribute.MOVEMENT_SPEED, .32); }
        if (type.equals("stalker")) { setAttribute(mob, Attribute.ATTACK_DAMAGE, 9); setAttribute(mob, Attribute.MOVEMENT_SPEED, .34); }
        if (type.equals("guardian")) { setAttribute(mob, Attribute.ATTACK_DAMAGE, 14); setAttribute(mob, Attribute.MOVEMENT_SPEED, .28); }
        if (type.equals("moth") || type.equals("wisp")) mob.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, false, false));
        if (type.equals("guardian")) mob.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        if ((type.equals("stalker") || type.equals("guardian")) && mob instanceof Mob aiMob) {
            new BukkitRunnable() {
                @Override public void run() {
                    if (!aiMob.isValid() || aiMob.isDead()) { cancel(); return; }
                    var target = aiMob.getWorld().getNearbyPlayers(aiMob.getLocation(), 18).stream().findFirst().orElse(null);
                    if (target != null) aiMob.setTarget(target);
                }
            }.runTaskTimer(this, 20L, 40L);
        }
    }
    private void setAttribute(LivingEntity e, Attribute a, double value) { if (e.getAttribute(a) != null) e.getAttribute(a).setBaseValue(value); }

    @EventHandler public void onCustomCreatureDeath(EntityDeathEvent event) {
        Entity e = event.getEntity();
        String type = e.getPersistentDataContainer().get(creatureTypeKey, PersistentDataType.STRING);
        if (type == null) return;
        event.getDrops().clear();
        switch (type) {
            case "wisp" -> event.getDrops().add(namedItem(Material.AMETHYST_SHARD, "§dVoid Shard", "§7A fragment humming with End energy.", "void_shard"));
            case "stalker" -> event.getDrops().add(namedItem(Material.ECHO_SHARD, "§5Stalker Core", "§7A cold fragment from the outer void.", "stalker_core"));
            case "guardian" -> { event.getDrops().add(namedItem(Material.PRISMARINE_CRYSTALS, "§3Guardian Crystal", "§7A powerful crystalline trophy.", "guardian_crystal")); event.getDrops().add(new ItemStack(Material.AMETHYST_SHARD, 2 + random.nextInt(3))); }
            case "moth" -> event.getDrops().add(namedItem(Material.GLOW_INK_SAC, "§bMoth Dust", "§7Softly glowing dust.", "moth_dust"));
        }
    }
    private ItemStack namedItem(Material material, String name, String lore, String modelId) {
        ItemStack item = new ItemStack(material);
        var meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(java.util.List.of(lore));
            meta.setItemModel(new NamespacedKey(this, modelId));
            item.setItemMeta(meta);
        }
        return item;
    }

    private record GenerationSettings(boolean enabled, double minimumDistance, int decorationAttempts,
                                      double rareStructureChance, int maxDecorationBlocks) { }

    private enum BiomeStyle { ETHEREAL, AMETHYST, CRIMSON, MUSHROOM, CELESTIAL }
    private BiomeStyle styleAt(int cx, int cz) {
        long h = mix(((long) (cx >> 3) * 341873128712L) ^ ((long) (cz >> 3) * 132897987541L));
        return BiomeStyle.values()[(int) Math.floorMod(h, 5)];
    }
    private long mix(long z) { z = (z ^ (z >>> 30)) * 0xbf58476d1ce4e5b9L; z = (z ^ (z >>> 27)) * 0x94d049bb133111ebL; return z ^ (z >>> 31); }

    private void startAmbientTask() {
        new BukkitRunnable() { @Override public void run() {
            if (!getConfig().getBoolean("effects.ambient-particles", true)) return;
            for (var player : Bukkit.getOnlinePlayers()) {
                if (player.getWorld().getEnvironment() != World.Environment.THE_END || random.nextDouble() > clampChance(getConfig().getDouble("effects.particle-chance-per-second", .18))) continue;
                Location l = player.getLocation().add(random.nextDouble() * 12 - 6, random.nextDouble() * 5, random.nextDouble() * 12 - 6);
                Particle ambient = switch (styleAt(player.getLocation().getChunk().getX(), player.getLocation().getChunk().getZ())) {
                    case ETHEREAL -> Particle.END_ROD;
                    case AMETHYST -> Particle.WITCH;
                    case CRIMSON -> Particle.ASH;
                    case MUSHROOM -> Particle.SPORE_BLOSSOM_AIR;
                    case CELESTIAL -> Particle.PORTAL;
                };
                player.spawnParticle(ambient, l, 2, .15, .25, .15, .01);
            }
        }}.runTaskTimer(this, 20L, 20L);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("beyondtheend.admin")) { sender.sendMessage(ChatColor.RED + "You do not have permission."); return true; }
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            sender.sendMessage(PREFIX + "Version 1.2.0 | Paper 1.21.11 | Java 21");
            sender.sendMessage(ChatColor.GRAY + "Five themed outer-End regions; newly generated chunks only."); return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> { reloadConfig(); refreshGenerationSettings(); sender.sendMessage(PREFIX + "Configuration reloaded."); }
            case "debug" -> sender.sendMessage(PREFIX + "Generation=" + getConfig().getBoolean("world-generation.enabled") + ", naturalSpawns=" + getConfig().getBoolean("creatures.natural-spawns"));
            case "locate" -> {
                if (args.length < 2) { sender.sendMessage(ChatColor.RED + "Usage: /beyondend locate <ethereal|amethyst|crimson|mushroom|celestial>"); return true; }
                if (!(sender instanceof org.bukkit.entity.Player p)) { sender.sendMessage("Players only."); return true; }
                String target = args[1].toUpperCase(Locale.ROOT);
                BiomeStyle wanted; try { wanted = BiomeStyle.valueOf(target); } catch (IllegalArgumentException ex) { sender.sendMessage(ChatColor.RED + "Unknown region."); return true; }
                int startX = p.getLocation().getChunk().getX(), startZ = p.getLocation().getChunk().getZ(); boolean found = false;
                for (int radius = 0; radius <= 128 && !found; radius++) for (int dx = -radius; dx <= radius && !found; dx++) for (int dz = -radius; dz <= radius && !found; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                    int cx = startX + dx, cz = startZ + dz;
                    if (Math.hypot(cx * 16.0, cz * 16.0) >= getConfig().getDouble("world-generation.minimum-distance-from-origin", 420) && styleAt(cx, cz) == wanted) {
                        sender.sendMessage(PREFIX + "Nearest " + wanted.name() + " region estimate: X " + (cx * 16 + 8) + ", Z " + (cz * 16 + 8)); found = true;
                    }
                }
                if (!found) sender.sendMessage(ChatColor.RED + "No region found in search radius.");
            }
            case "spawn" -> {
                if (!(sender instanceof org.bukkit.entity.Player p)) { sender.sendMessage("Players only."); return true; }
                if (args.length < 2) { sender.sendMessage(ChatColor.RED + "Usage: /beyondend spawn <moth|wisp|stalker|guardian>"); return true; }
                if (p.getWorld().getEnvironment() != World.Environment.THE_END) { sender.sendMessage(ChatColor.RED + "You must be in the End."); return true; }
                String type = args[1].toLowerCase(Locale.ROOT);
                if (!java.util.List.of("moth", "wisp", "stalker", "guardian").contains(type)) { sender.sendMessage(ChatColor.RED + "Unknown creature."); return true; }
                Location spawnAt = p.getLocation();
                if (spawnAt.getBlock().isLiquid() || !spawnAt.getBlock().isPassable()) {
                    sender.sendMessage(ChatColor.RED + "Move to a clear space before spawning a creature."); return true;
                }
                spawnCreature(p.getWorld(), spawnAt, type); sender.sendMessage(PREFIX + "Spawned " + type + ".");
            }
            default -> sender.sendMessage(ChatColor.YELLOW + "Usage: /beyondend <info|reload|locate|spawn|debug>");
        }
        return true;
    }
}
